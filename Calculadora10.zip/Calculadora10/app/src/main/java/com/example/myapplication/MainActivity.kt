 package com.example.myapplication

 import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
 import android.widget.Button
 import android.widget.EditText
 import android.widget.TextView

 class MainActivity : AppCompatActivity() {
     @SuppressLint ("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //Variables en Android
        var et1 = findViewById<View>(R.id.eTextValor1) as EditText
         var et2 = findViewById<View>(R.id.eTextValor2) as EditText
         var res = findViewById<View>(R.id.eTextResultado) as TextView
         var btn = findViewById<View>(R.id.btnSuma) as Button

         //Botón suma
         btn.setOnClickListener {
                 var resultado = et1.text.toString().toInt() +
                         et2.text.toString().toInt()
             res.text = "El resultado es: " + resultado
         }


    }
}